package com.example.cameraapp

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.CancellationSignal
import android.provider.MediaStore
import android.util.Size

/**
 * Reads back only what this app itself saved, i.e. the rows inside
 * Pictures/CameraApp and Movies/CameraApp. Nothing else on the device
 * is touched, so no broad storage permission is ever required.
 */
object MediaRepository {

    const val PHOTO_FOLDER = "Pictures/CameraApp/"
    const val VIDEO_FOLDER = "Movies/CameraApp/"

    fun loadAll(context: Context): List<MediaItem> {
        val items = ArrayList<MediaItem>(64)
        items.addAll(query(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false))
        items.addAll(query(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true))
        return items.sortedByDescending { it.dateAddedSeconds }
    }

    fun loadLatest(context: Context): MediaItem? = loadAll(context).firstOrNull()

    private fun query(context: Context, baseUri: Uri, isVideo: Boolean): List<MediaItem> {
        val projection = if (isVideo) {
            arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.Video.Media.DURATION
            )
        } else {
            arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED
            )
        }
        val selection = MediaStore.MediaColumns.RELATIVE_PATH + " IN (?,?)"
        val args = arrayOf(PHOTO_FOLDER, VIDEO_FOLDER)
        val sort = MediaStore.MediaColumns.DATE_ADDED + " DESC"
        val out = ArrayList<MediaItem>(64)

        try {
            context.contentResolver.query(baseUri, projection, selection, args, sort)
                ?.use { cursor ->
                    val idIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                    val nameIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val dateIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                    val durationIndex =
                        if (isVideo) cursor.getColumnIndex(MediaStore.Video.Media.DURATION) else -1

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idIndex)
                        out.add(
                            MediaItem(
                                uri = ContentUris.withAppendedId(baseUri, id),
                                displayName = cursor.getString(nameIndex) ?: "",
                                dateAddedSeconds = cursor.getLong(dateIndex),
                                isVideo = isVideo,
                                durationMillis = if (durationIndex >= 0) {
                                    cursor.getLong(durationIndex)
                                } else {
                                    0L
                                }
                            )
                        )
                    }
                }
        } catch (e: Exception) {
            // A missing column on a vendor ROM must never crash the gallery.
        }
        return out
    }

    /** Small thumbnail for the camera screen / gallery cells. */
    fun loadThumbnail(context: Context, uri: Uri, sizePx: Int): Bitmap? = try {
        context.contentResolver.loadThumbnail(uri, Size(sizePx, sizePx), CancellationSignal())
    } catch (e: Exception) {
        null
    }
}
