package com.example.cameraapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.MediaController
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.cameraapp.databinding.ActivityViewerBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Full-screen single item with share and delete. */
class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_IS_VIDEO = "extra_is_video"
    }

    private lateinit var binding: ActivityViewerBinding
    private lateinit var loader: ExecutorService
    private var itemUri: Uri? = null
    private var isVideo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loader = Executors.newSingleThreadExecutor()

        val uriString = intent.getStringExtra(EXTRA_URI)
        if (uriString == null) {
            finish()
            return
        }
        itemUri = Uri.parse(uriString)
        isVideo = intent.getBooleanExtra(EXTRA_IS_VIDEO, false)

        binding.viewerTitle.text = intent.getStringExtra(EXTRA_NAME) ?: ""
        binding.closeButton.setOnClickListener { finish() }
        binding.shareButton.setOnClickListener { share() }
        binding.deleteButton.setOnClickListener { confirmDelete() }

        if (isVideo) {
            showVideo()
        } else {
            showPhoto()
        }
    }

    private fun showPhoto() {
        binding.videoView.visibility = View.GONE
        binding.fullImage.visibility = View.VISIBLE

        val uri = itemUri ?: return
        val maxPx = (1440 * resources.displayMetrics.density).toInt()
        loader.execute {
            val bitmap = MediaRepository.loadThumbnail(this, uri, maxPx)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (bitmap != null) {
                    binding.fullImage.setImageBitmap(bitmap)
                } else {
                    toast(getString(R.string.open_failed))
                }
            }
        }
    }

    private fun showVideo() {
        binding.fullImage.visibility = View.GONE
        binding.videoView.visibility = View.VISIBLE

        val uri = itemUri ?: return
        try {
            binding.videoView.setMediaController(MediaController(this).also {
                it.setAnchorView(binding.videoView)
            })
            binding.videoView.setVideoURI(uri)
            binding.videoView.setOnPreparedListener { player ->
                player.isLooping = false
                binding.videoView.start()
            }
            binding.videoView.setOnErrorListener { _, _, _ ->
                toast(getString(R.string.open_failed))
                true
            }
        } catch (t: Throwable) {
            toast(getString(R.string.open_failed))
        }
    }

    private fun share() {
        val uri = itemUri ?: return
        val mime = if (isVideo) "video/mp4" else "image/jpeg"
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, getString(R.string.share)))
        } catch (t: Throwable) {
            toast(getString(R.string.share_failed))
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete)
            .setPositiveButton(R.string.delete) { _, _ -> deleteItem() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteItem() {
        val uri = itemUri ?: return
        val removed = try {
            contentResolver.delete(uri, null, null) > 0
        } catch (t: Throwable) {
            false
        }
        if (removed) {
            toast(getString(R.string.deleted))
            finish()
        } else {
            toast(getString(R.string.delete_needs_permission))
        }
    }

    override fun onStop() {
        if (::binding.isInitialized) {
            try {
                binding.videoView.stopPlayback()
            } catch (t: Throwable) {
                // Not prepared.
            }
        }
        super.onStop()
    }

    override fun onDestroy() {
        loader.shutdownNow()
        super.onDestroy()
    }

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }
}
