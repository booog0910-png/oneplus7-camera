package com.example.cameraapp

import android.net.Uri

data class MediaItem(
    val uri: Uri,
    val displayName: String,
    val dateAddedSeconds: Long,
    val isVideo: Boolean,
    val durationMillis: Long
)
