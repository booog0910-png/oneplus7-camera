package com.example.cameraapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cameraapp.databinding.ActivityGalleryBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Grid of everything this app has saved. */
class GalleryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryBinding
    private lateinit var adapter: MediaAdapter
    private lateinit var loader: ExecutorService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loader = Executors.newSingleThreadExecutor()
        adapter = MediaAdapter { item ->
            startActivity(
                Intent(this, ViewerActivity::class.java)
                    .putExtra(ViewerActivity.EXTRA_URI, item.uri.toString())
                    .putExtra(ViewerActivity.EXTRA_NAME, item.displayName)
                    .putExtra(ViewerActivity.EXTRA_IS_VIDEO, item.isVideo)
            )
        }

        binding.mediaGrid.layoutManager = GridLayoutManager(this, 3)
        binding.mediaGrid.adapter = adapter
        binding.backButton.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        loader.execute {
            val items = MediaRepository.loadAll(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                adapter.submit(items)
                binding.emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                binding.mediaGrid.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    override fun onDestroy() {
        adapter.release()
        loader.shutdownNow()
        super.onDestroy()
    }
}
