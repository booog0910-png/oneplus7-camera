package com.example.cameraapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cameraapp.databinding.ItemMediaBinding
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MediaAdapter(
    private val onItemClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    private var items: List<MediaItem> = emptyList()
    private val loader: ExecutorService = Executors.newFixedThreadPool(2)

    fun submit(list: List<MediaItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun release() {
        loader.shutdownNow()
    }

    class ViewHolder(val binding: ItemMediaBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ViewHolder(ItemMediaBinding.inflate(inflater, parent, false))
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val cell = holder.binding
        val context = cell.root.context

        // Tag guards against recycled cells showing the previous item's picture.
        cell.root.tag = item.uri

        cell.thumbImage.setImageDrawable(null)
        cell.playIcon.visibility = if (item.isVideo) View.VISIBLE else View.GONE

        if (item.isVideo && item.durationMillis > 0) {
            cell.durationText.visibility = View.VISIBLE
            cell.durationText.text = formatDuration(item.durationMillis)
        } else {
            cell.durationText.visibility = View.GONE
        }

        cell.root.setOnClickListener { onItemClick(item) }

        val sizePx = (220 * context.resources.displayMetrics.density).toInt()
        loader.execute {
            val bitmap = MediaRepository.loadThumbnail(context, item.uri, sizePx)
            cell.root.post {
                if (cell.root.tag == item.uri && bitmap != null) {
                    cell.thumbImage.setImageBitmap(bitmap)
                }
            }
        }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        holder.binding.root.tag = null
    }

    private fun formatDuration(millis: Long): String {
        val totalSeconds = millis / 1000
        return String.format(Locale.US, "%d:%02d", totalSeconds / 60, totalSeconds % 60)
    }
}
