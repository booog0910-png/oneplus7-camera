package com.example.cameraapp

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream

/**
 * Turns the just-captured frame into a square photo for the 1:1 mode.
 * The capture itself is always taken at 4:3 (the only ratio every sensor
 * exposes), then the centre square is cut out here. EXIF rotation is baked
 * into the pixels because re-encoding drops the orientation tag.
 */
object ImageCropper {

    private const val MAX_EDGE = 2600

    fun cropSquareInPlace(resolver: ContentResolver, uri: Uri): Boolean {
        return try {
            val orientation = resolver.openInputStream(uri)?.use { stream ->
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth / (sample * 2) >= MAX_EDGE ||
                bounds.outHeight / (sample * 2) >= MAX_EDGE
            ) {
                sample *= 2
            }

            val options = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: return false

            val upright = applyRotation(decoded, orientation)

            val side = minOf(upright.width, upright.height)
            val left = (upright.width - side) / 2
            val top = (upright.height - side) / 2
            val square = Bitmap.createBitmap(upright, left, top, side, side)

            val bytes = ByteArrayOutputStream()
            square.compress(Bitmap.CompressFormat.JPEG, 95, bytes)

            resolver.openOutputStream(uri, "wt")?.use { out ->
                out.write(bytes.toByteArray())
                out.flush()
            } ?: return false

            if (square !== upright) square.recycle()
            if (upright !== decoded) upright.recycle()
            decoded.recycle()
            true
        } catch (e: Throwable) {
            // A failed crop must never lose the original photo.
            false
        }
    }

    private fun applyRotation(source: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            else -> return source
        }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }
}
