package com.example.cameraapp

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.core.ZoomState
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.example.cameraapp.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Camera screen.
 *
 * Written for the OnePlus 7 (GM1901, Android 11 / API 30) but works on any
 * camera-equipped device from API 29 onwards.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var mainHandler: Handler

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var torchOn = false
    private var gridOn = false
    private var timerSeconds = 0
    private val aspectModes = listOf("4:3", "16:9", "1:1")
    private var aspectIndex = 0

    private var isVideoMode = false
    private var isRecording = false
    private var countdownRunning = false
    private var cameraReady = false
    private var hasFrontCamera = true

    private var lastThumbUri: Uri? = null
    private var audioPermissionGranted = false

    private var zoomRatioMin = 1f
    private var zoomRatioMax = 1f

    private val zoomObserver = Observer<ZoomState> { state ->
        zoomRatioMin = state.minZoomRatio
        zoomRatioMax = state.maxZoomRatio
        binding.zoomChip.text = String.format(Locale.US, "%.1fx", state.zoomRatio)
    }

    private var recordingSeconds = 0
    private val ticker = object : Runnable {
        override fun run() {
            if (!isRecording) return
            recordingSeconds++
            binding.recordingTime.text = formatClock(recordingSeconds)
            mainHandler.postDelayed(this, 1000L)
        }
    }

    // ------------------------------------------------------------------ permissions

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            requestAudioPermission()
            startCamera()
        } else {
            showPermissionDialog()
        }
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> audioPermissionGranted = granted }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()
        mainHandler = Handler(Looper.getMainLooper())

        setupListeners()
        setupGestures()
        syncUi()

        if (hasCameraPermission()) {
            requestAudioPermission()
            startCamera()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshThumbnail()
    }

    override fun onStop() {
        // Never leave a recording or a countdown running in the background.
        if (isRecording) {
            stopRecording()
        }
        cancelCountdown()
        super.onStop()
    }

    override fun onDestroy() {
        releaseTorch()
        mainHandler.removeCallbacksAndMessages(null)
        releaseRecording()
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ setup

    private fun setupListeners() {
        binding.shutterButton.setOnClickListener { onShutterPressed() }
        binding.switchCameraButton.setOnClickListener { switchCamera() }
        binding.flashButton.setOnClickListener { cycleFlash() }
        binding.gridButton.setOnClickListener { toggleGrid() }
        binding.timerButton.setOnClickListener { cycleTimer() }
        binding.aspectButton.setOnClickListener { cycleAspect() }
        binding.modePhoto.setOnClickListener { setVideoMode(false) }
        binding.modeVideo.setOnClickListener { setVideoMode(true) }
        binding.thumbnailFrame.setOnClickListener { openGallery() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val current = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: return false
                applyZoom((current * detector.scaleFactor).coerceIn(zoomRatioMin, zoomRatioMax))
                binding.zoomChip.visibility = View.VISIBLE
                mainHandler.removeCallbacks(hideZoomChip)
                mainHandler.postDelayed(hideZoomChip, 1600L)
                return true
            }
        })

        binding.previewContainer.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            if (event.actionMasked == MotionEvent.ACTION_UP && !scaleDetector.isInProgress) {
                focusAt(event.x, event.y)
            }
            true
        }
    }

    private val hideZoomChip = Runnable { binding.zoomChip.visibility = View.GONE }

    // ------------------------------------------------------------------ camera

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestAudioPermission() {
        audioPermissionGranted =
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        if (!audioPermissionGranted) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startCamera() {
        val existing = cameraProvider
        if (existing != null) {
            bindUseCases(existing)
            return
        }
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                bindUseCases(provider)
            } catch (t: Throwable) {
                showCameraError(t)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases(provider: ProcessCameraProvider) {
        val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        if (!safeHasCamera(provider, selector)) {
            if (lensFacing != CameraSelector.LENS_FACING_BACK) {
                lensFacing = CameraSelector.LENS_FACING_BACK
                bindUseCases(provider)
            } else {
                showCameraError(IllegalStateException(getString(R.string.no_front_camera)))
            }
            return
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(binding.previewView.surfaceProvider)
        }

        imageCapture = null
        videoCapture = null
        isRecording = false

        try {
            provider.unbindAll()
            camera = if (isVideoMode) {
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.fromOrderedList(
                            listOf(Quality.FHD, Quality.HD, Quality.SD),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val video = VideoCapture.withOutput(recorder)
                video.targetRotation = currentRotation()
                videoCapture = video
                provider.bindToLifecycle(this, selector, preview, video)
            } else {
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setTargetRotation(currentRotation())
                    .setTargetAspectRatio(buildAspectRatio())
                    .setFlashMode(flashMode)
                    .build()
                imageCapture = capture
                provider.bindToLifecycle(this, selector, preview, capture)
            }
        } catch (t: Throwable) {
            showCameraError(t)
            return
        }

        camera?.cameraInfo?.zoomState?.apply {
            // Same Observer instance every time: LiveData dedupes it by (owner, observer),
            // so rebinding the camera cannot stack duplicate observers.
            observe(this@MainActivity, zoomObserver)
            value?.let { state ->
                zoomRatioMin = state.minZoomRatio
                zoomRatioMax = state.maxZoomRatio
            }
        }

        cameraReady = true
        syncUi()
        updateSwitchAvailability()
        refreshThumbnail()
    }

    private fun safeHasCamera(provider: ProcessCameraProvider, selector: CameraSelector): Boolean =
        try {
            provider.hasCamera(selector)
        } catch (t: Throwable) {
            false
        }

    private fun buildAspectRatio(): Int = when (aspectModes[aspectIndex]) {
        "16:9" -> AspectRatio.RATIO_16_9
        else -> AspectRatio.RATIO_4_3
    }

    private fun currentRotation(): Int =
        binding.previewView.display?.rotation ?: Surface.ROTATION_0

    private fun applyZoom(ratio: Float) {
        val safe = ratio.coerceIn(zoomRatioMin, zoomRatioMax)
        try {
            camera?.cameraControl?.setZoomRatio(safe)
        } catch (t: Throwable) {
            return
        }
        binding.zoomChip.text = String.format(Locale.US, "%.1fx", safe)
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        if (!cameraReady) return

        val viewWidth = binding.previewView.width.toFloat()
        val viewHeight = binding.previewView.height.toFloat()
        if (viewWidth <= 0f || viewHeight <= 0f) return

        val factory = SurfaceOrientedMeteringPointFactory(viewWidth, viewHeight)

        val point = factory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()

        try {
            cam.cameraControl.startFocusAndMetering(action)
            binding.focusRing.show(x, y)
        } catch (t: Throwable) {
            // Some sensors refuse metering; ignoring keeps the UI responsive.
        }
    }

    private fun switchCamera() {
        if (isRecording) {
            toast(getString(R.string.stop_recording_first))
            return
        }
        val provider = cameraProvider ?: return
        val next = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        val selector = CameraSelector.Builder().requireLensFacing(next).build()
        if (!safeHasCamera(provider, selector)) {
            toast(getString(R.string.no_front_camera))
            return
        }
        lensFacing = next
        releaseTorch()
        cameraReady = false
        bindUseCases(provider)
    }

    private fun releaseTorch() {
        if (!torchOn) return
        torchOn = false
        try {
            camera?.cameraControl?.enableTorch(false)
        } catch (t: Throwable) {
            // Camera already released.
        }
    }

    private fun updateSwitchAvailability() {
        val provider = cameraProvider ?: return
        val frontSelector = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_FRONT).build()
        hasFrontCamera = safeHasCamera(provider, frontSelector)
        binding.switchCameraButton.isEnabled = hasFrontCamera && !isRecording
        binding.switchCameraButton.alpha = if (hasFrontCamera) 1f else 0.3f
    }

    // ------------------------------------------------------------------ toggles

    private fun cycleFlash() {
        if (isVideoMode) {
            toggleTorch()
            return
        }
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
            ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flashMode
        toast(
            getString(
                when (flashMode) {
                    ImageCapture.FLASH_MODE_ON -> R.string.flash_on
                    ImageCapture.FLASH_MODE_AUTO -> R.string.flash_auto
                    else -> R.string.flash_off
                }
            )
        )
        syncUi()
    }

    /** In video mode the flash button drives the LED as a continuous torch. */
    private fun toggleTorch() {
        val cam = camera
        if (cam == null || !cam.cameraInfo.hasFlashUnit()) {
            toast(getString(R.string.no_flash_unit))
            return
        }
        torchOn = !torchOn
        try {
            cam.cameraControl.enableTorch(torchOn)
        } catch (t: Throwable) {
            torchOn = false
        }
        syncUi()
    }

    private fun toggleGrid() {
        gridOn = !gridOn
        toast(getString(if (gridOn) R.string.grid_on else R.string.grid_off))
        syncUi()
    }

    private fun cycleTimer() {
        timerSeconds = when (timerSeconds) {
            0 -> 3
            3 -> 10
            else -> 0
        }
        toast(
            getString(
                when (timerSeconds) {
                    3 -> R.string.timer_3
                    10 -> R.string.timer_10
                    else -> R.string.timer_off
                }
            )
        )
        syncUi()
    }

    private fun cycleAspect() {
        if (isRecording) {
            toast(getString(R.string.stop_recording_first))
            return
        }
        aspectIndex = (aspectIndex + 1) % aspectModes.size
        val provider = cameraProvider
        if (provider != null) {
            cameraReady = false
            bindUseCases(provider)
        }
        syncUi()
    }

    private fun setVideoMode(video: Boolean) {
        if (isVideoMode == video) return
        if (isRecording) {
            toast(getString(R.string.stop_recording_first))
            return
        }
        isVideoMode = video
        releaseTorch()
        val provider = cameraProvider
        if (provider != null) {
            cameraReady = false
            bindUseCases(provider)
        }
        syncUi()
    }

    private fun syncUi() {
        binding.gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
        binding.gridButton.alpha = if (gridOn) 1f else 0.45f
        binding.flashButton.alpha = when {
            isVideoMode -> if (torchOn) 1f else 0.45f
            flashMode == ImageCapture.FLASH_MODE_OFF -> 0.45f
            else -> 1f
        }
        binding.timerButton.text = if (timerSeconds == 0) "0s" else timerSeconds.toString() + "s"
        binding.timerButton.alpha = if (timerSeconds == 0) 0.45f else 1f
        binding.aspectButton.text = aspectModes[aspectIndex]
        binding.aspectButton.visibility = if (isVideoMode) View.INVISIBLE else View.VISIBLE

        binding.modePhoto.setTextColor(
            ContextCompat.getColor(this, if (isVideoMode) R.color.text_muted else R.color.white)
        )
        binding.modeVideo.setTextColor(
            ContextCompat.getColor(this, if (isVideoMode) R.color.white else R.color.text_muted)
        )

        val shutterIcon = when {
            isRecording -> R.drawable.shutter_stop
            isVideoMode -> R.drawable.shutter_video
            else -> R.drawable.shutter_photo
        }
        binding.shutterButton.setImageResource(shutterIcon)
        binding.shutterButton.contentDescription = getString(
            when {
                isRecording -> R.string.desc_stop
                isVideoMode -> R.string.desc_record
                else -> R.string.desc_shutter
            }
        )

        val busy = !cameraReady || countdownRunning
        binding.shutterButton.isEnabled = !busy || isRecording
        binding.shutterButton.alpha = if (busy && !isRecording) 0.45f else 1f

        binding.recordingBadge.visibility = if (isRecording) View.VISIBLE else View.GONE
        binding.switchCameraButton.isEnabled = !isRecording && hasFrontCamera
    }

    // ------------------------------------------------------------------ shutter

    private fun onShutterPressed() {
        if (!cameraReady && !isRecording) return
        if (isRecording) {
            stopRecording()
            return
        }
        if (countdownRunning) return

        if (isVideoMode) {
            if (timerSeconds > 0) runCountdown { startRecording() } else startRecording()
        } else {
            if (timerSeconds > 0) runCountdown { capturePhoto() } else capturePhoto()
        }
    }

    private fun cancelCountdown() {
        countdownRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        binding.countdown.visibility = View.GONE
    }

    private fun runCountdown(action: () -> Unit) {
        countdownRunning = true
        binding.countdown.visibility = View.VISIBLE
        var remaining = timerSeconds
        binding.countdown.text = remaining.toString()

        val step = object : Runnable {
            override fun run() {
                remaining -= 1
                if (remaining <= 0) {
                    binding.countdown.visibility = View.GONE
                    countdownRunning = false
                    syncUi()
                    action()
                } else {
                    binding.countdown.text = remaining.toString()
                    binding.countdown.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
        mainHandler.postDelayed(step, 1000L)
        syncUi()
    }

    // ------------------------------------------------------------------ photo

    private fun capturePhoto() {
        val capture = imageCapture ?: return
        capture.targetRotation = currentRotation()

        binding.shutterButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)

        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
            .format(System.currentTimeMillis()) + ".jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            put(MediaStore.Images.Media.RELATIVE_PATH, MediaRepository.PHOTO_FOLDER)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }

        val resolver = contentResolver
        val uri = try {
            resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        } catch (t: Throwable) {
            null
        }

        if (uri == null) {
            toast(getString(R.string.photo_failed))
            return
        }

        val options = ImageCapture.OutputFileOptions.Builder(resolver, uri, ContentValues()).build()

        capture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val square = aspectModes[aspectIndex] == "1:1"
                if (square) {
                    ImageCropper.cropSquareInPlace(resolver, uri)
                }
                try {
                    resolver.update(
                        uri,
                        ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) },
                        null,
                        null
                    )
                } catch (t: Throwable) {
                    // Ignore: the row is still readable.
                }
                runOnUiThread {
                    lastThumbUri = uri
                    flashScreen()
                    refreshThumbnail()
                    toast(getString(R.string.photo_saved))
                }
            }

            override fun onError(exception: ImageCaptureException) {
                try {
                    resolver.delete(uri, null, null)
                } catch (t: Throwable) {
                    // Nothing else to clean up.
                }
                runOnUiThread { toast(getString(R.string.photo_failed)) }
            }
        })
    }

    // ------------------------------------------------------------------ video

    private fun startRecording() {
        val video = videoCapture ?: return
        if (isRecording) return

        val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
            .format(System.currentTimeMillis()) + ".mp4"

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            put(MediaStore.Video.Media.RELATIVE_PATH, MediaRepository.VIDEO_FOLDER)
        }

        val outputOptions = MediaStoreOutputOptions
            .Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()

        try {
            var pending = video.output.prepareRecording(this, outputOptions)
            if (audioPermissionGranted) {
                pending = pending.withAudioEnabled()
            }
            activeRecording = pending.start(
                ContextCompat.getMainExecutor(this)
            ) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        isRecording = true
                        recordingSeconds = 0
                        binding.recordingTime.text = formatClock(0)
                        mainHandler.post(ticker)
                        syncUi()
                    }
                    is VideoRecordEvent.Finalize -> {
                        isRecording = false
                        mainHandler.removeCallbacks(ticker)
                        binding.recordingBadge.visibility = View.GONE
                        activeRecording = null
                        val ok = !event.hasError() &&
                            event.outputResults.outputUri != Uri.EMPTY
                        if (ok) {
                            lastThumbUri = event.outputResults.outputUri
                            refreshThumbnail()
                            toast(getString(R.string.video_saved))
                        } else {
                            toast(getString(R.string.video_failed))
                        }
                        syncUi()
                    }
                    else -> Unit
                }
            }
        } catch (t: Throwable) {
            activeRecording = null
            isRecording = false
            mainHandler.removeCallbacks(ticker)
            syncUi()
            toast(getString(R.string.video_failed))
        }
    }

    private fun stopRecording() {
        val recording = activeRecording ?: return
        try {
            recording.stop()
        } catch (t: Throwable) {
            isRecording = false
            activeRecording = null
            mainHandler.removeCallbacks(ticker)
            syncUi()
        }
    }

    private fun releaseRecording() {
        val recording = activeRecording ?: return
        try {
            recording.close()
        } catch (t: Throwable) {
            // Already finalised.
        }
        activeRecording = null
        isRecording = false
        mainHandler.removeCallbacks(ticker)
    }

    // ------------------------------------------------------------------ helpers

    private fun refreshThumbnail() {
        if (cameraExecutor.isShutdown) return
        try { cameraExecutor.execute {
            if (isFinishing || isDestroyed) return@execute
            val latest = MediaRepository.loadLatest(this)
            if (latest == null) {
                runOnUiThread {
                    binding.thumbnail.setImageDrawable(null)
                    binding.thumbnailEmpty.visibility = View.VISIBLE
                }
                return@execute
            }
            val sizePx = (160 * resources.displayMetrics.density).toInt()
            val bitmap: Bitmap? = MediaRepository.loadThumbnail(this, latest.uri, sizePx)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (bitmap != null) {
                    binding.thumbnail.setImageBitmap(bitmap)
                    binding.thumbnail.scaleType = ImageView.ScaleType.CENTER_CROP
                    binding.thumbnailEmpty.visibility = View.GONE
                } else {
                    binding.thumbnail.setImageDrawable(null)
                    binding.thumbnailEmpty.visibility = View.VISIBLE
                }
            }
        } } catch (t: Throwable) {
            // Shutting down; nothing to show.
        }
    }

    private fun openGallery() {
        startActivity(Intent(this, GalleryActivity::class.java))
    }

    private fun flashScreen() {
        binding.flashView.animate().cancel()
        binding.flashView.alpha = 0.8f
        binding.flashView.animate().alpha(0f).setDuration(260).start()
    }

    private fun formatClock(totalSeconds: Int): String = String.format(
        Locale.US, "%02d:%02d", totalSeconds / 60, totalSeconds % 60
    )

    private fun showCameraError(t: Throwable) {
        cameraReady = false
        syncUi()
        toast(getString(R.string.camera_error, t.message ?: t.javaClass.simpleName), long = true)
    }

    private fun showPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.permission_title)
            .setMessage(R.string.permission_message)
            .setPositiveButton(R.string.open_settings) { _, _ ->
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                startActivity(intent)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(message: String, long: Boolean = false) {
        Toast.makeText(this, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }
}
