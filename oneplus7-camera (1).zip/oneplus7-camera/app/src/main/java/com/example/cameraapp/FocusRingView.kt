package com.example.cameraapp

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

/** Draws a short shrinking ring where the user tapped to focus. */
class FocusRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }

    private var centerX = 0f
    private var centerY = 0f
    private var progress = 1f
    private var animator: ValueAnimator? = null

    fun show(x: Float, y: Float) {
        centerX = x
        centerY = y
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 750L
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun clear() {
        animator?.cancel()
        progress = 1f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (progress >= 1f) return
        val radius = (34f - 12f * progress) * density
        paint.alpha = ((1f - progress) * 220f).toInt().coerceIn(0, 255)
        canvas.drawCircle(centerX, centerY, radius, paint)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }
}
